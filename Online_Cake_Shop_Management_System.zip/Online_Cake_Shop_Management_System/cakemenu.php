<?php
include("header.php");
?>

<!-- gallery section -->
<section id="gallery" class="parallax-section">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
        <p style="font-family:Lucida Calligraphy;font-size:24px;color:#600">Cake Menu</p>
        <hr>
      </div>
      
      
      <div class="col-md-12 col-sm-4 wow fadeInUp" data-wow-delay="0.3s"> 
		  	<?php
			include("categoryslider.php");
        	?>
      </div>
      


    </div>
  </div>
</section>

<?php
include("footer.php");
?>